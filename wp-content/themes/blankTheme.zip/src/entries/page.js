import '../scss/page.scss';
import Swal from 'sweetalert2';
import 'swiper/dist/css/swiper.css';
import Swiper from 'swiper';

/*
const homebannerSwiper = new Swiper('.x-swiper-full .swiper-container', {
    autoplay: {
        delay: 5000,
    },
    slidesPerView: 1,
    // Responsive breakpoints
    pagination: {
        el: '.x-swiper-full .swiper-pagination',
        type: 'bullets',
    }
});*/
