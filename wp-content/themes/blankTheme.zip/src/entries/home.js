import '../scss/home.scss';
import 'swiper/dist/css/swiper.css';
import Swiper from 'swiper';