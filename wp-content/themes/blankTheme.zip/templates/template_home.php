<?php /* Template Name: home */
set_query_var('ENTRY', 'home');
get_header();
?>
<!-- home content -->
<section class="home-banner">
    <div class="emperadorHome">
    <div class="x-swiper-full x-marco">
            <div class="swiper-container">
		        <!-- Additional required wrapper -->
		        <div class="swiper-wrapper">
                    <?php
                    $banners = get_field('banners');
                    $aux = 0;
                    if ($banners) {
                        foreach ($banners as $banner) {
                        $imagen = $banner['imagen'];
                        if ( wp_is_mobile() ) {
                            $imagen = $banner['imagen_mobile'];
                        }
						?>
			            <div class="swiper-slide homeslide" style="background-image:url(<?php echo $imagen; ?>);">
                            <div class="isTitle">
                                <div class="x-container">
                                    <?php if($aux == 0) { ?><h1 style="color:<?php echo $banner['color_title']; ?>"><?php } else { ?><h2 style="color:<?php echo $banner['color_title']; ?>"><?php } ?>
                                    <?php echo $banner['title']?>
                                    <?php if($aux == 0) { ?></h1><?php } else { ?></h2><?php } ?>
                                    <span style="color:<?php echo $banner['color_title']; ?>"><?php echo $banner['subtitle']?></span>
                                    <a href="<?php echo $banner['link']?>" class="btn"><?php echo $banner['text_button']?></a>
                                </div>
                            </div>
                        </div>
                    <?php 
                        $aux++;
                        }
                    }
                    ?>
                </div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </div>
    <div class="x-container">
        
        <div class="x-title services-title">
            <h2><?php the_field('title_servicios'); ?></h2>
        </div>
        <div class="x-swiper-full-3 servicios-slide">
            <div class="swiper-container">
		        <!-- Additional required wrapper -->
		        <div class="swiper-wrapper">
                    <?php
                    $servicios = get_field('servicios');
                    if ($servicios) {
                        foreach ($servicios as $servicio) {
						?>
			            <div class="swiper-slide">
                            <div class="servicesContent">
                                <a href="<?php echo $servicio['link']; ?>" class="imagenLink"><img src="<?php echo $servicio['imagen']; ?>"></a>
                                <a href="<?php echo $servicio['link']; ?>" class="btn"><?php echo $servicio['text']; ?></a>
                            </div>                            
                        </div>
                    <?php 
                        }
                    }
                    ?>
                </div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
        <div class="x-title services-title">
            <h2><?php the_field('title_agentes'); ?></h2>
        </div>
        <div class="x-dowContent">
            <div class="singleflex-dowContent">
            <?php
                $best = get_field('agentes');
                if ($best) {
                    foreach ($best as $bes) {
                        ?>
                <div class="singleflex-item">
                    <img src="<?php echo $bes['imagen']; ?>">
                    <h3><?php echo $bes['text']; ?></h3>
                </div>
                        <?php
                    }
                }
            ?>
            </div>
            <div class="single-btn">
                <a href="<?php the_field('agentes_link'); ?>" class="btn"><?php the_field('agentes_text'); ?></a>
            </div>
        </div>        
        <div class="x-title services-title">
            <h2><?php the_field('title_testimonios'); ?></h2>
        </div>
        <div class="x-swiper-full-3 testimonios-slide">
            <div class="swiper-container">
		        <!-- Additional required wrapper -->
		        <div class="swiper-wrapper">
                    <?php
                    $testimonios = get_field('testimonios');
                    if ($testimonios) {
                        foreach ($testimonios as $testimonio) {
						?>
			            <div class="swiper-slide">
                            <div class="testimoniosContent">
                                <img src="<?php echo $testimonio['imagen']; ?>">
                                <div class="testimoniosContent__content">
                                    <h4><b><?php echo $testimonio['nombre']; ?></b> opina sobre</h4>
                                    <h3><?php echo $testimonio['producto']; ?></h3>
                                    <div class="description">
                                        <?php echo $testimonio['opinion']; ?>
                                    </div>
                                    <div class="valoration afterTitle href" data-href="valoration">
                                        <div class="valoration_starts" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                                        <?php	
                                            $Mycont = $testimonio['valoration'];							
                                            for ($i=1; $i < 6; $i++) { 
                                                $active = '';
                                                if ($i < $Mycont) {
                                                    $active = 'active';
                                                }
                                                echo '<span class="start '.$active.'"></span>';
                                            }                                            
                                        ?>
                                        </div>								
                                    </div>
                                </div>
                            </div>                            
                        </div>
                    <?php 
                        }
                    }
                    ?>
                </div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </div>
</section>
<?php
get_footer();
?>
