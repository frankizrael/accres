
<script>
    var ajaxUrl = '<?php echo site_url()?>/wp-admin/admin-ajax.php';
</script>
<?php wp_footer() ?>
</body>
</html>