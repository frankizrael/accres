<!doctype html>
<html lang="<?php bloginfo( 'language' ) ?>">
<head>    
    <meta charset="<?php bloginfo( 'charset' ) ?>">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<?php
        $entry = get_query_var('ENTRY');
        load_assets(['main', $entry]);
        wp_head();
    ?>
</head>
<body <?php body_class(); ?>>
<header>
    <?php
        if (get_field('franja_informativa','options')){
    ?>
    <div class="top-frame">
        <div class="x-container">
            <div class="x-close"></div>
            <div class="x-frame">
                <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 5H4V1.87188C4 0.8375 4.8375 0 5.87187 0H12.1313C13.1656 0 14.0031 0.8375 14.0031 1.87188V10.1313C14.0031 11.1656 13.1656 12.0031 12.1313 12.0031H10V13.0031C10 14.1094 9.10625 15.0031 8 15.0031H2C0.89375 15.0031 0 14.1094 0 13.0031V7C0 5.89375 0.89375 5 2 5ZM10 7V10H12V2H11C11 2.55313 10.5531 3 10 3H8C7.44687 3 7 2.55313 7 2H6V5H8C9.10625 5 10 5.89375 10 7ZM2.9375 12H4.08125L4.9375 9.4L5.81875 12H6.9375L7.9375 8H6.9375L6.33125 10.6781L5.475 8H4.42188L3.58437 10.6781L2.9375 8H1.9375L2.9375 12Z" fill="white"/>
                </svg>
                <?php echo get_field('franja_informativa','options'); ?>
            </div>  
        </div>
    </div>
    <?php } ?>        
        <div class="svg-background">            
        </div>
    <div class="bot-frame">
        <div class="x-container">
            <div class="bot-frame__flex">
                <div class="bot-frame__flex__left">
                    <div class="bot-frame__list">
                        <ul>
                            <?php 
                                $list_menu = get_field('menu_top','options');
                                if ($list_menu) {
                                    foreach ($list_menu as $li) {
                                        ?>
                                <li>
                                    <a href="<?php echo $li['link']; ?>" class="pekosimplelink"><?php echo $li['text']; ?></a>
                                </li>
                                        <?php
                                    }
                                }
                            ?>                                        
                        </ul>
                    </div>
                </div>      
                <div class="bot-frame__flex__mobile">
                    <a href="javascript:void(0)">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect x="2" y="5" width="20" height="2" rx="1" fill="#F048A5"/>
                            <rect x="2" y="11" width="20" height="2" rx="1" fill="#F048A5"/>
                            <rect x="2" y="17" width="20" height="2" rx="1" fill="#F048A5"/>
                        </svg>
                    </a>
                </div>          
                <div class="bot-frame__logo">
                    <a href="<?php echo site_url(); ?>">
                        <img src="<?php echo get_field('logo','options'); ?>">
                    </a>
                </div>
                <div class="bot-frame__cart">
                    <div class="searchInputContent">
                        <div class="bodySearchInput">
                            <?php echo do_shortcode('[wcas-search-form]'); ?>
                        </div>
                    </div>        
                    <a href="<?php echo site_url();?>/mi-cuenta" class="myaccountt">
                        <p>Cuenta</p>
                        <svg width="35" height="35" viewBox="0 0 35 35" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17.5" cy="17.5" r="17.5" fill="#D9FFFF"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M21.5 11.911C21.5 14.3963 19.4853 16.411 17 16.411C14.5147 16.411 12.5 14.3963 12.5 11.911C12.5 9.42573 14.5147 7.41101 17 7.41101C19.4853 7.41101 21.5 9.42573 21.5 11.911ZM26 24.6609C26 29.9109 8 29.9109 8 24.6609C8 15.3796 26 15.4734 26 24.6609Z" fill="#3BD4D4"/>
                        </svg>
                    </a>
                    <a href="<?php echo site_url(); ?>/carrito" class="myCartPekokis">
                        <svg width="52" height="51" viewBox="0 0 52 51" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M51.0897 17.5096C50.3417 16.589 49.2195 16.0553 48.0357 16.0571H44.8941L32.6694 0.922437C32.3095 0.448945 31.7739 0.142497 31.1844 0.0718592C30.5955 0.00123394 30.0029 0.173191 29.542 0.548417C29.0811 0.923648 28.7915 1.47023 28.7395 2.06347C28.6869 2.65611 28.8766 3.24506 29.2641 3.69586L39.2422 16.0214H12.1516L22.1297 3.69586C22.5417 3.2494 22.7504 2.65246 22.7082 2.04571C22.6653 1.43956 22.3746 0.87763 21.9044 0.493799C21.4343 0.109969 20.8271 -0.0613673 20.2265 0.019694C19.626 0.100759 19.0855 0.427485 18.7335 0.922468L6.50036 16.0657H3.94644C2.76437 16.0663 1.64467 16.5987 0.894814 17.5162C0.145548 18.4331 -0.155021 19.6393 0.0763627 20.8024L5.14862 46.3958C5.4094 47.6929 6.10969 48.8604 7.13022 49.6993C8.15007 50.5382 9.42823 50.9982 10.7474 51H41.2527C42.5725 50.9982 43.8501 50.5382 44.8706 49.6993C45.8911 48.8604 46.5908 47.6929 46.8522 46.3958L51.9244 20.8024C52.1558 19.6349 51.8497 18.4245 51.0907 17.5095L51.0897 17.5096ZM19.4091 38.2528C19.4091 39.4682 18.4266 40.4539 17.2151 40.4539C16.0037 40.4539 15.0212 39.4682 15.0212 38.2528V29.246C15.0212 28.0306 16.0037 27.045 17.2151 27.045C18.4266 27.045 19.4091 28.0306 19.4091 29.246V38.2528ZM28.1849 38.2528C28.1849 39.4682 27.2024 40.4539 25.9909 40.4539C24.7795 40.4539 23.797 39.4682 23.797 38.2528V29.246C23.797 28.0306 24.7795 27.045 25.9909 27.045C27.2024 27.045 28.1849 28.0306 28.1849 29.246V38.2528ZM36.9607 38.2528C36.9607 39.4682 35.9782 40.4539 34.7667 40.4539C33.5553 40.4539 32.5728 39.4682 32.5728 38.2528V29.246C32.5728 28.0306 33.5553 27.045 34.7667 27.045C35.9782 27.045 36.9607 28.0306 36.9607 29.246V38.2528Z" fill="#9ED94C"/>
                        </svg>
                        <?php if(WC()->cart->get_cart_contents_count() > 0) { ?>
                            <span class="count">
                                <?php echo WC()->cart->get_cart_contents_count(); ?>
                            </span>
                        <?php } ?>
                    </a>      
                </div>
            </div>
            <div class="bot-frame__menu">
                <ul>
                    <?php 
                        $menu = get_field('menu_bot','options');
                        if ($menu) {
                            $aux = 0;
                            foreach ($menu as $li) {
                                ?>
                        <li class="contentLiMenu">
                            <a href="<?php echo $li['link']; ?>" data-id="#submenu_<?php echo $aux;?>" class="<?php if($li['submenu'] && count($li['submenu']) > 1) echo 'jsActiveSubMenu'; ?>">
                                <span style="background-image:url(<?php echo $li['imagen']; ?>);" class="backgroundIcon"></span>
                                <span class="valueText <?php if($li['resaltar']) { echo 'active'; } ?>"><?php echo $li['text']; ?></span>
                            </a>
                        </li>
                                <?php
                                $aux++;
                            }
                        }
                    ?> 
                </ul>             
            </div>
        </div>
    </div>
</header>
<div class="subMenuSectionCore">
    <div class="subMenuSectionCore__content">
        <?php
            if ($menu) {
                $aux = 0;
                foreach ($menu as $li) {
                    $submenu = $li['submenu'];
                    if ($submenu) {
                        ?>
                <article style="display:none" class="submenuitem" id="submenu_<?php echo $aux;?>">
                    <div class="x-container">
                        <div class="flexInCore">
                            <?php 
                                $len = count($submenu);
                                $valueclass = '';
                                if ($len > 4) { $valueclass = 'two'; }
                            ?>
                            <ul class="<?php echo $valueclass; ?>">
                                <?php
                                    foreach ($submenu as $sub) {
                                        ?>
                                    <li>
                                        <a href="<?php echo $sub['link']; ?>" data-image="<?php echo $sub['imagen']; ?>"><?php echo $sub['text']; ?></a>
                                    </li>
                                        <?php
                                    }
                                ?>
                            </ul>
                            <div class="backgroundImageFin"></div>
                        </div>
                    </div>
                </article>
                        <?php
                    }
                    $aux++;
                }
            }
        ?>                  
    </div>
    <div class="subMenuSectionCore__background"></div>
</div>
<div class="background background-fondo1">
    <svg width="548" height="712" viewBox="0 0 548 712" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M547.374 314.061C549.977 376.57 538.169 439.936 509.187 498.445C460.874 595.938 371.293 672.701 262.477 686.923C212.862 705.971 160.517 714.987 108.997 710.67C-70.6394 695.558 -192.947 540.794 -210.882 374.284C-212.279 368.379 -213.295 362.411 -213.993 356.442C-214.914 352.506 -215.929 348.506 -216.628 344.665C-238.594 227.584 -174.726 109.455 -93.7169 27.6443C-31.3727 -35.2772 51.7637 -68.3253 137.788 -72.865C148.137 -77.7222 160.644 -80.008 175.468 -78.5794C283.935 -68.23 399.228 -39.6582 472.46 47.3906C535.598 122.439 551.564 218.853 547.374 314.061ZM324.535 294.727C322.758 246.504 300.696 198.313 258.699 164.059C154.2 78.8831 7.57652 153.202 -21.1513 275.806C-38.6102 350.284 8.08447 420.57 66.5877 462.73C127.821 506.857 202.958 490.159 260.159 447.555C287.998 426.824 315.171 399.173 325.805 365.141C333.328 340.95 331.297 317.49 324.535 294.727Z" fill="#ABECEC"/>
    </svg>
</div>
<div class="background background-fondo2">
    <svg width="184" height="327" viewBox="0 0 184 327" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M317.741 162.547C318.818 188.397 313.935 214.601 301.95 238.797C281.971 279.114 244.927 310.859 199.929 316.74C179.412 324.617 157.766 328.346 136.462 326.56C62.1777 320.311 11.6005 256.31 4.18397 187.451C3.60639 185.009 3.18637 182.541 2.89758 180.073C2.5169 178.445 2.09691 176.791 1.80812 175.202C-7.27555 126.785 19.1353 77.9338 52.6346 44.1017C78.4155 18.0812 112.794 4.41443 148.368 2.53706C152.647 0.528406 157.819 -0.416843 163.949 0.173937C208.803 4.45381 256.479 16.2694 286.762 52.2676C312.871 83.3033 319.474 123.174 317.741 162.547ZM225.592 154.551C224.857 134.609 215.734 114.68 198.367 100.515C155.154 65.2911 94.5219 96.0248 82.6422 146.727C75.4225 177.526 94.7319 206.593 118.924 224.027C144.246 242.276 175.317 235.37 198.971 217.752C210.483 209.179 221.72 197.744 226.117 183.67C229.228 173.666 228.388 163.965 225.592 154.551Z" fill="#D1EDAB"/>
    </svg>
</div>
<!-- mobile menu -->
<div class="menuMobile">
    <div class="menuMobile__front">
        <ul class="menuMobile__front__top">
            <?php 
                $menu = get_field('menu_bot','options');
                if ($menu) {
                    $aux = 0;
                    foreach ($menu as $li) {
                        ?>
                <li class="mobile__link">
                    <a href="javascript:void(0)" data-id="#submenumobile_<?php echo $aux;?>" class="">                        
                        <img src="<?php echo $li['imagen']; ?>"><?php echo $li['text']; ?>                        
                    </a>
                </li>
                        <?php
                        $aux++;
                    }
                }
            ?> 
        </ul>
        <ul class="menuMobile__front__bot">
            <?php 
                $list_menu = get_field('menu_top','options');
                if ($list_menu) {
                    foreach ($list_menu as $li) {
                        ?>
                <li>
                    <a href="<?php echo $li['link']; ?>" class="pekosimplelink"><?php echo $li['text']; ?></a>
                </li>
                        <?php
                    }
                }
            ?>                                        
        </ul>
    </div>
    <div class="menuMobile__submenu">
        <?php
            if ($menu) {
                $aux = 0;
                foreach ($menu as $li) {
                    $submenu = $li['submenu'];
                    if ($submenu) {
                        ?>
                <article style="display:none" class="menuMobile__submenu__item" id="submenumobile_<?php echo $aux;?>">
                    <div class="flexInCore">
                        <h3><?php echo $li['text']; ?> </h3>
                        <a href="<?php echo $li['link']; ?>" class="btn">Ver más</a>
                        <ul>
                            <?php
                                foreach ($submenu as $sub) {
                                    ?>
                                <li>
                                    <a href="<?php echo $sub['link']; ?>" data-image="<?php echo $sub['imagen']; ?>"><?php echo $sub['text']; ?></a>
                                </li>
                                    <?php
                                }
                            ?>
                        </ul>
                    </div>
                </article>
                        <?php
                    }
                    $aux++;
                }
            }
        ?>    
    </div>
</div>

